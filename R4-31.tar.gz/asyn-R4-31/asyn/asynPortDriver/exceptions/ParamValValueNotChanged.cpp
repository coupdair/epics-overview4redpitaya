/*
 * ParamValValueNotChanged.cpp
 *
 *  Created on: Dec 20, 2011
 *      Author: hammonds
 */

#include "ParamValValueNotChanged.h"

ParamValValueNotChanged::ParamValValueNotChanged(const std::string& description):
logic_error(description){
}


camonitor -#5 testARB:A1:ArrayDataNRB testARB:A1:ArrayDataWRB testARB:A1:ScalarData
